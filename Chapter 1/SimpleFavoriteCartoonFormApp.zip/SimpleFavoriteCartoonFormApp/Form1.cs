using System.Windows.Forms;

namespace SimpleFavoriteCartoonFormApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            string[] cartoons = { "Bliss", "Blossom", "Bubbles", "Buttercup" };
            comboBox1.Items.AddRange(cartoons);

            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.SelectedIndex = 0;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string selectedCharacter = comboBox1.SelectedItem.ToString();
            switch (selectedCharacter)
            {
                case "Bliss":
                    pictureBox1.Image = Image.FromFile(@"C:\Users\OO140\Pictures\bliss.jpg");
                    break;
                case "Blossom":
                    pictureBox1.Image = Image.FromFile(@"C:\Users\OO140\Pictures\blossom.jpg");
                    break;
                case "Bubbles":
                    pictureBox1.Image = Image.FromFile(@"C:\Users\OO140\Pictures\Bubbles.jpg");
                    break;
                case "Buttercup":
                    pictureBox1.Image = Image.FromFile(@"C:\Users\OO140\Pictures\Buttercup.jpg");
                    break;
            }

            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = null;
        }
    }
}
